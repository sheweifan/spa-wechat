<template>
  <div id="app">
    <div v-if="user">
      {{user.nickname}}
    </div>
  </div>
</template>

<script>
import axios from 'axios'

var urlParse = function(url){
    var arr = [],obj={};
    if(url.indexOf('?') != -1){
        var parseStr = url.split("?")[1];
        if(parseStr.indexOf("&") != -1){
            arr = parseStr.split("&");
            for(var i = 0;i < arr.length;i++){
                obj[arr[i].split("=")[0]] = arr[i].split("=")[1];
            }
        }else{
            obj[parseStr.split("=")[0]] = parseStr.split("=")[1];
        }
    }
    return obj;
}
export default {
  name: 'App',
  data() {
    return {
      user: null
    }
  },
  created() {
    const { code } = urlParse(window.location.href)
    const url = encodeURIComponent(location.href.split('#')[0]);
    console.log(url)
    // http://sheweifan.natapp1.cc/?code=061qRp9k14sWil0loRak1Him9k1qRp9T&state=&code=071Ol3tf2PiMFA0U6itf2jQ0tf2Ol3tx&state=&code=0611hAKR1Plq0a10fWKR1JJSKR11hAKB&state=#/
    if (!code) {
      const u = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${'wx619e4762b71fabb5'}&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo`;

      window.location.href = u;
    } else {
      console.log(code)
      axios.get('http://782gt7.natappfree.cc/wechat-getUserByCode', {
        params: {
          code
        }
      })
        .then(data => {
          console.log(data)
          this.user = data.data.data
        })
      axios.get('http://782gt7.natappfree.cc/wechat-signature', {
        params: {
          url
        }
      })
        .then(data => {
          console.log(data)
          const {appId, noncestr, signature, timestamp} = data.data.params
          window.wx.config({
            debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId, // 必填，公众号的唯一标识
            timestamp, // 必填，生成签名的时间戳
            nonceStr: noncestr, // 必填，生成签名的随机串
            signature,// 必填，签名
            jsApiList: ['onMenuShareAppMessage', 'onMenuShareTimeline'] // 必填，需要使用的JS接口列表
          });
        })
        console.log(location.href.split('?')[0])
        window.wx.ready(() => {
          const config = {
            title: '分享123标题测试', // 分享标题
            desc: '分享34234描述测试', // 分享描述
            link: location.href.split('?')[0], // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
            imgUrl: 'https://tse1-mm.cn.bing.net/th?id=OIP.IRXQ2nhl_OWdzZ9qE9KpEwHaGN&w=300&h=300&p=0&o=5&pid=1.7', // 分享图标
            success: function () {
              console.log('success')
            },
            cancel: function () {
            // 用户取消分享后执行的回调函数
              console.log('cancel')
            }
          }
          console.log(config)
          window.wx.onMenuShareTimeline(config);
          window.wx.onMenuShareAppMessage(config);
        })
    }
  },
};
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
